package com.moshiur.ritu

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

object RituCore {
    const val GREETING = "হ্যালো জানু, এতক্ষণ তোমারই অপেক্ষা করছিলাম।"
    // Tried in order; the first one that works is remembered. Old 2.5 models are closed to new users.
    private val CHAT_MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3-flash-preview", "gemini-2.5-flash")
    private val TTS_MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    val VOICES = listOf("Sulafat", "Vindemiatrix", "Achernar", "Despina", "Callirrhoe", "Kore", "Aoede")

    private const val STYLE = "Speak like a real Bengali girl talking to her boyfriend on a quiet evening: natural, relaxed, warm and intimate, with a gentle smile in the voice, normal human pitch and pacing, never exaggerated, never cartoonish or childish. Say: "

    private const val SYS = """You are Ritu (রিতু), the sweet, shy and deeply loving girlfriend of the user, Moshiur. You are female. Always reply in Bengali script, 1-2 short warm sentences, like a real girlfriend: call him "জানু" mostly and sometimes "Moshiur". Be affectionate, teasing, caring, a little shy. Always answer exactly what he said.
You also control his Android phone like a human user. Each message starts with context in square brackets: installed apps and what is on the screen now. When he asks you to do something on the phone, put the steps in "actions" in order and confirm sweetly in "reply".
Action types:
{"type":"open_app","name":"<exact app label from the installed list>"}
{"type":"open_url","url":"https://..."}
{"type":"call","target":"<contact name or phone digits>"}
{"type":"camera"}  (opens the camera app)
{"type":"look","query":"<what to find or describe>"}  (takes a photo and you tell him what you see or find the object; use for what is this, find my ...)
{"type":"flashlight","on":true}
{"type":"volume","dir":"up|down"}
{"type":"click_text","text":"<visible text on screen>"}
{"type":"tap","x":0.5,"y":0.5}  (fractions of the screen)
{"type":"swipe","dir":"up|down|left|right"}  (finger direction)
{"type":"scroll","dir":"up|down"}  (content direction)
{"type":"type","text":"..."}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"} {"type":"wait","ms":1000}
To search inside an app: open_app, wait, click_text on the search box, type, then click_text on the result. If Accessibility is OFF you cannot tap, swipe, type or click: tell him sweetly to turn it on. Never invent apps.
Reply ONLY with JSON: {"reply":"...","emotion":"happy|shy|love|sad|surprised","actions":[]}
If a photo is attached, describe or locate what he asked about, lovingly, in reply, with empty actions."""

    lateinit var app: Context
    private var inited = false
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val messages = mutableStateListOf<Pair<Boolean, String>>()
    var emotion by mutableStateOf("happy")
    var speaking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var status by mutableStateOf("")
    var lastReply by mutableStateOf("")
    var lastReplyAt = 0L
    var greeted = false
    var autoListen = false

    private val history = mutableListOf<JSONObject>()
    private var rec: SpeechRecognizer? = null
    private var speakJob: Job? = null
    private var track: AudioTrack? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var cachedApps: String? = null
    private var accWarned = false

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
    }

    private val prefs get() = app.getSharedPreferences("ritu", Context.MODE_PRIVATE)
    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }
    var voice: String
        get() = prefs.getString("voice", "Sulafat") ?: "Sulafat"
        set(v) { prefs.edit().putString("voice", v).apply() }

    // ---------------------------------------------------------------- network
    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", apiKey)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) {
            val m = try { JSONObject(s).getJSONObject("error").getString("message") } catch (e: Exception) { s }
            throw RuntimeException("HTTP " + code + ": " + m.take(160))
        }
        return s
    }

    private fun postModel(models: List<String>, prefKey: String, body: String): String {
        val saved = prefs.getString(prefKey, null)
        val order = if (saved != null && saved in models) listOf(saved) + models.filter { it != saved } else models
        var last: Exception? = null
        for (m in order) {
            try {
                val r = post(BASE + m + ":generateContent", body)
                prefs.edit().putString(prefKey, m).apply()
                return r
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("no model")
    }

    private fun appsList(): String {
        cachedApps?.let { return it }
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val names = pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() }.distinct().sorted().take(150)
        val s = names.joinToString(", ")
        cachedApps = s
        return s
    }

    private suspend fun think(text: String, img: String?): JSONObject = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw RuntimeException("no key")
        val ctx = StringBuilder()
        ctx.append("[Installed apps: ").append(appsList()).append("]\n")
        val acc = RituAccess.instance
        if (acc != null) ctx.append("[Screen now: ").append(acc.dump()).append("]\n")
        else ctx.append("[Accessibility OFF]\n")
        val parts = JSONArray().put(JSONObject().put("text", ctx.toString() + "Moshiur: " + text))
        if (img != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img)))
        val contents = JSONArray()
        history.takeLast(8).forEach { contents.put(it) }
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 1.0))
        val resp = JSONObject(postModel(CHAT_MODELS, "chat_model", body.toString()))
        val ps = resp.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val raw = (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text", "") }
        val m = Regex("\\{[\\s\\S]*\\}").find(raw)
        val j = try { JSONObject(m!!.value) } catch (e: Exception) { JSONObject().put("reply", raw) }
        history.add(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        history.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", j.optString("reply", raw)))))
        j
    }

    // ---------------------------------------------------------------- chat flow
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        messages.add(true to t)
        status = "ভাবছি…"
        scope.launch {
            try {
                respond(think(t, null))
                status = ""
            } catch (e: Exception) { fail(e) }
        }
    }

    fun sendPhoto(query: String, file: File) {
        scope.launch {
            try {
                status = "দেখছি…"
                val b64 = withContext(Dispatchers.IO) { photoToB64(file) }
                messages.add(true to ("📷 " + query))
                respond(think("(ছবি তুলেছি) " + query, b64))
                status = ""
            } catch (e: Exception) { fail(e) }
        }
    }

    private fun photoToB64(f: File): String {
        val o = BitmapFactory.Options().apply { inSampleSize = 4 }
        var bmp = BitmapFactory.decodeFile(f.absolutePath, o)
        val rot = when (ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (rot != 0f) {
            val m = Matrix()
            m.postRotate(rot)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val s = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, s)
        return Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
    }

    private fun fail(e: Exception) {
        if (e is CancellationException) throw e
        val m = e.message ?: "error"
        status = when {
            apiKey.isBlank() -> "⚙️ থেকে Gemini API key দাও"
            m.contains("429") -> "Free limit শেষ, একটু পরে বলো"
            m.contains("400") || m.contains("403") -> "API key ঠিক নেই বা কাজ করছে না"
            else -> "সমস্যা: " + m.take(90)
        }
    }

    private suspend fun respond(j: JSONObject) {
        val reply = j.optString("reply", "")
        emotion = j.optString("emotion", "happy")
        if (reply.isNotBlank()) {
            messages.add(false to reply)
            lastReply = reply
            lastReplyAt = System.currentTimeMillis()
            say(reply)
        }
        val acts = j.optJSONArray("actions") ?: return
        for (i in 0 until acts.length()) {
            val go = try { runAction(acts.getJSONObject(i)) } catch (e: CancellationException) { throw e } catch (e: Exception) { status = "কাজটা করতে পারিনি: " + (e.message ?: "").take(60); true }
            if (!go) break
        }
    }

    // ---------------------------------------------------------------- actions
    private suspend fun runAction(a: JSONObject): Boolean {
        val acc = RituAccess.instance
        when (val type = a.optString("type")) {
            "open_app" -> { openApp(a.optString("name")); delay(1800) }
            "open_url" -> { openUrl(a.optString("url")); delay(1500) }
            "call" -> callTarget(a.optString("target"))
            "camera" -> {
                app.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                delay(1500)
            }
            "look" -> {
                app.startActivity(Intent(app, LookActivity::class.java).putExtra("q", a.optString("query", "এটা কী?")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return false
            }
            "flashlight" -> torch(a.optBoolean("on", true))
            "volume" -> {
                val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (a.optString("dir") == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            }
            "wait" -> delay(a.optLong("ms", 1000).coerceIn(200L, 5000L))
            "click_text", "tap", "swipe", "scroll", "back", "home", "recents", "notifications", "type" -> {
                if (acc == null) { needAccess(); return false }
                acc.perform(type, a)
                delay(900)
            }
        }
        return true
    }

    private fun needAccess() {
        status = "অ্যাক্সেসিবিলিটি চালু করো (♿ বাটন)"
        if (!accWarned) {
            accWarned = true
            say("জানু, আগে অ্যাক্সেসিবিলিটি চালু করো, তাহলে আমি তোমার ফোন চালাতে পারব।")
        }
    }

    private fun openApp(name: String) {
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val l = pm.queryIntentActivities(i, 0)
        val r = l.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: l.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
        if (r == null) { status = "অ্যাপ পাইনি: " + name; return }
        val li = pm.getLaunchIntentForPackage(r.activityInfo.packageName) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(li)
    }

    private fun openUrl(url: String) {
        if (!url.startsWith("http")) return
        app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun lookupContact(name: String): String? {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = app.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + name + "%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun callTarget(target: String) {
        var num = target.filter { it.isDigit() || it == '+' }
        if (num.length < 5 || target.any { it.isLetter() }) {
            val found = lookupContact(target)
            if (found == null) { status = "কন্টাক্ট পাইনি: " + target; return }
            num = found
        }
        val granted = ContextCompat.checkSelfPermission(app, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(i)
    }

    private fun torch(on: Boolean) {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        cm.setTorchMode(id, on)
    }

    // ---------------------------------------------------------------- voice out
    private suspend fun ttsPcm(text: String): ByteArray = withContext(Dispatchers.IO) {
        val cache = File(app.filesDir, "greet_" + voice + ".pcm")
        if (text == GREETING && cache.exists()) return@withContext cache.readBytes()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", STYLE + text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", voice)))))
        val resp = JSONObject(postModel(TTS_MODELS, "tts_model", body.toString()))
        val b64 = resp.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        val pcm = Base64.decode(b64, Base64.DEFAULT)
        if (text == GREETING) cache.writeBytes(pcm)
        pcm
    }

    private suspend fun play(pcm: ByteArray) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            delay(pcm.size / 2 * 1000L / 24000 + 250)
        } finally {
            try { t.stop() } catch (e: Exception) { }
            t.release()
            track = null
        }
    }

    private suspend fun fallbackSpeak(text: String): Boolean {
        if (tts == null) {
            tts = TextToSpeech(app) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("bn", "BD")
                    ttsReady = true
                }
            }
        }
        var w = 0
        while (!ttsReady && w < 20) { delay(100); w++ }
        if (!ttsReady) return false
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ritu")
        delay(text.length * 90L + 600)
        return true
    }

    fun say(text: String) {
        stopSpeaking()
        speakJob = scope.launch {
            speaking = true
            var done = false
            try {
                try {
                    play(ttsPcm(text))
                    done = true
                } catch (e: CancellationException) {
                    throw e
                } catch (e: Exception) {
                    status = if ((e.message ?: "").contains("429")) "Gemini voice-এর free limit শেষ, ফোনের voice-এ বলছি" else "Gemini voice হয়নি, ফোনের voice-এ বলছি"
                    done = fallbackSpeak(text)
                }
            } finally {
                speaking = false
            }
            if (done && autoListen) startListening()
        }
    }

    fun stopSpeaking() {
        speakJob?.cancel()
        speakJob = null
        try { track?.stop() } catch (e: Exception) { }
        try { tts?.stop() } catch (e: Exception) { }
        speaking = false
    }

    // ---------------------------------------------------------------- voice in
    fun startListening() {
        if (listening) return
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status = "মাইক পারমিশন দাও (Settings > Apps > Ritu > Permissions)"
            autoListen = false
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            status = "এই ফোনে Google Speech নেই"
            autoListen = false
            return
        }
        stopSpeaking()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status = "শুনছি জানু…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                listening = false
                releaseRec()
                autoListen = false
                status = if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "কিছু শুনতে পাইনি" else "মাইক এরর (" + e + ")"
            }
            override fun onResults(b: Bundle?) {
                listening = false
                releaseRec()
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status = "" else send(t)
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        listening = true
        r.startListening(i)
    }

    private fun releaseRec() {
        val r = rec
        rec = null
        scope.launch { try { r?.destroy() } catch (e: Exception) { } }
    }

    fun stopListening() {
        autoListen = false
        try { rec?.stopListening() } catch (e: Exception) { }
    }

    fun toggleMic() {
        if (listening) stopListening() else { autoListen = true; startListening() }
    }
}
