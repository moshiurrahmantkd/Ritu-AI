package com.moshiur.ritu

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import org.json.JSONObject

class RituAccess : AccessibilityService() {
    companion object {
        @Volatile
        var instance: RituAccess? = null
    }

    override fun onServiceConnected() {
        instance = this
    }

    override fun onUnbind(intent: Intent?): Boolean {
        instance = null
        return super.onUnbind(intent)
    }

    override fun onDestroy() {
        instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun dump(): String {
        val root = rootInActiveWindow ?: return "empty"
        val out = ArrayList<String>()
        walk(root, out)
        return out.joinToString(" | ")
    }

    private fun walk(n: AccessibilityNodeInfo, out: MutableList<String>) {
        if (out.size >= 70) return
        val t = (n.text ?: n.contentDescription)?.toString()
        if (!t.isNullOrBlank()) out.add((if (n.isClickable) "[btn]" else "") + t.take(40))
        else if (n.isEditable) out.add("[input]")
        for (i in 0 until n.childCount) {
            val c = n.getChild(i)
            if (c != null) walk(c, out)
        }
    }

    fun perform(type: String, a: JSONObject) {
        when (type) {
            "back" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "home" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "recents" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "notifications" -> performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
            "click_text" -> clickText(a.optString("text"))
            "tap" -> tap(a.optDouble("x", 0.5).toFloat(), a.optDouble("y", 0.5).toFloat())
            "swipe" -> swipe(a.optString("dir"), false)
            "scroll" -> swipe(a.optString("dir"), true)
            "type" -> typeText(a.optString("text"))
        }
    }

    private fun gesture(x1: Float, y1: Float, x2: Float, y2: Float, dur: Long) {
        val p = Path()
        p.moveTo(x1, y1)
        p.lineTo(x2, y2)
        val g = GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(p, 0, dur)).build()
        dispatchGesture(g, null, null)
    }

    private fun tap(fx: Float, fy: Float) {
        val m = resources.displayMetrics
        val x = fx.coerceIn(0f, 1f) * m.widthPixels
        val y = fy.coerceIn(0f, 1f) * m.heightPixels
        gesture(x, y, x + 1f, y + 1f, 60)
    }

    private fun swipe(dir: String, scroll: Boolean) {
        val m = resources.displayMetrics
        val w = m.widthPixels.toFloat()
        val h = m.heightPixels.toFloat()
        // for "scroll down" the content moves up, so the finger swipes up
        val d = if (scroll) when (dir) { "down" -> "up"; "up" -> "down"; "left" -> "right"; else -> "left" } else dir
        when (d) {
            "up" -> gesture(w / 2, h * 0.72f, w / 2, h * 0.28f, 320)
            "down" -> gesture(w / 2, h * 0.28f, w / 2, h * 0.72f, 320)
            "left" -> gesture(w * 0.8f, h / 2, w * 0.2f, h / 2, 320)
            "right" -> gesture(w * 0.2f, h / 2, w * 0.8f, h / 2, 320)
        }
    }

    private fun clickText(text: String) {
        val root = rootInActiveWindow ?: return
        val n = root.findAccessibilityNodeInfosByText(text).firstOrNull() ?: return
        var c: AccessibilityNodeInfo? = n
        while (c != null && !c.isClickable) c = c.parent
        (c ?: n).performAction(AccessibilityNodeInfo.ACTION_CLICK)
    }

    private fun findEditable(n: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        if (n.isEditable) return n
        for (i in 0 until n.childCount) {
            val c = n.getChild(i) ?: continue
            val r = findEditable(c)
            if (r != null) return r
        }
        return null
    }

    private fun typeText(text: String) {
        val root = rootInActiveWindow ?: return
        val f = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: findEditable(root) ?: return
        val b = Bundle()
        b.putCharSequence(AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE, text)
        f.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, b)
    }
}
