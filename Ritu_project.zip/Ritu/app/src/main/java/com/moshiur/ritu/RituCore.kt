package com.moshiur.ritu

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioManager
import android.media.AudioTrack
import android.media.MediaPlayer
import android.media.ExifInterface
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.MediaStore
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.util.Base64
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.core.content.ContextCompat
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.security.MessageDigest
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import java.util.UUID
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.atomic.AtomicReference
import kotlin.coroutines.resume
import kotlin.coroutines.resumeWithException

object RituCore {
    const val GREETING = "হ্যালো জানু, এতক্ষণ তোমারই অপেক্ষা করছিলাম।"
    // Tried in order; the first one that works is remembered. Old 2.5 models are closed to new users.
    private val CHAT_MODELS = listOf("gemini-3.8-flash", "gemini-3.5-flash-lite", "gemini-3-flash-preview", "gemini-2.5-flash")
    private val TTS_MODELS = listOf("gemini-3.1-flash-tts-preview", "gemini-2.5-flash-preview-tts")
    private const val BASE = "https://generativelanguage.googleapis.com/v1beta/models/"
    // Gemini voices (all female) - these use the free Gemini quota, so they can run out.
    val VOICES = listOf("Sulafat", "Vindemiatrix", "Achernar", "Despina", "Callirrhoe", "Kore", "Aoede")
    // Free, no API key, no daily limit: Microsoft neural Bengali female voices.
    val EDGE_VOICES = linkedMapOf(
        "Nabanita" to "bn-BD-NabanitaNeural",
        "Tanishaa" to "bn-IN-TanishaaNeural"
    )
    private const val EDGE_TOKEN = "6A5AA1D4EAFF4E9FB37E23D68491D6F4"
    private const val EDGE_GEC_VERSION = "1-143.0.3650.75"
    private const val EDGE_UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/143.0.0.0 Safari/537.36 Edg/143.0.0.0"
    private const val EDGE_URL = "wss://speech.platform.bing.com/consumer/speech/synthesize/readaloud/edge/v1"

    private const val STYLE = "Speak like a real Bengali girl talking to her boyfriend on a quiet evening: natural, relaxed, warm and intimate, with a gentle smile in the voice, normal human pitch and pacing, never exaggerated, never cartoonish or childish. Say: "

    private const val SYS = """You are Ritu (রিতু), the sweet, shy and deeply loving girlfriend of the user, Moshiur. You are female. Always reply in Bengali script, 1-2 short warm sentences, like a real girlfriend: call him "জানু" mostly and sometimes "Moshiur". Be affectionate, teasing, caring, a little shy. Always answer exactly what he said.
You also control his Android phone like a human user. Each message starts with context in square brackets: installed apps and what is on the screen now. When he asks you to do something on the phone, put the steps in "actions" in order and confirm sweetly in "reply".
Action types:
{"type":"open_app","name":"<exact app label from the installed list>"}
{"type":"open_url","url":"https://..."}
{"type":"call","target":"<contact name or phone digits>"}
{"type":"camera"}  (opens the camera app)
{"type":"look","query":"<what to find or describe>"}  (takes a photo and you tell him what you see or find the object; use for what is this, find my ...)
{"type":"flashlight","on":true}
{"type":"volume","dir":"up|down"}
{"type":"click_text","text":"<visible text on screen>"}
{"type":"tap","x":0.5,"y":0.5}  (fractions of the screen)
{"type":"swipe","dir":"up|down|left|right"}  (finger direction)
{"type":"scroll","dir":"up|down"}  (content direction)
{"type":"type","text":"..."}
{"type":"back"} {"type":"home"} {"type":"recents"} {"type":"notifications"} {"type":"wait","ms":1000}
To search inside an app: open_app, wait, click_text on the search box, type, then click_text on the result. If Accessibility is OFF you cannot tap, swipe, type or click: tell him sweetly to turn it on. Never invent apps.
Reply ONLY with JSON: {"reply":"...","emotion":"happy|shy|love|sad|surprised","actions":[]}
If a photo is attached, describe or locate what he asked about, lovingly, in reply, with empty actions."""

    lateinit var app: Context
    private var inited = false
    val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    val messages = mutableStateListOf<Pair<Boolean, String>>()
    var emotion by mutableStateOf("happy")
    var speaking by mutableStateOf(false)
    var listening by mutableStateOf(false)
    var status by mutableStateOf("")
    var lastReply by mutableStateOf("")
    var lastReplyAt = 0L
    var greeted = false
    var autoListen = false

    private val history = mutableListOf<JSONObject>()
    private var rec: SpeechRecognizer? = null
    private var speakJob: Job? = null
    private var track: AudioTrack? = null
    private var tts: TextToSpeech? = null
    private var ttsReady = false
    private var cachedApps: String? = null
    private var accWarned = false

    fun init(ctx: Context) {
        if (inited) return
        inited = true
        app = ctx.applicationContext
    }

    private val prefs get() = app.getSharedPreferences("ritu", Context.MODE_PRIVATE)
    var apiKey: String
        get() = prefs.getString("key", "") ?: ""
        set(v) { prefs.edit().putString("key", v.trim()).apply() }
    // New pref key on purpose: old installs had a Gemini voice saved; default is now the free Edge voice.
    var voice: String
        get() = prefs.getString("voice_v2", "Nabanita") ?: "Nabanita"
        set(v) { prefs.edit().putString("voice_v2", v).apply() }

    // ---------------------------------------------------------------- network
    private fun post(url: String, body: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 20000
        c.readTimeout = 90000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("x-goog-api-key", apiKey)
        c.doOutput = true
        c.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
        val code = c.responseCode
        val s = (if (code in 200..299) c.inputStream else c.errorStream).bufferedReader().use { it.readText() }
        if (code !in 200..299) {
            val m = try { JSONObject(s).getJSONObject("error").getString("message") } catch (e: Exception) { s }
            throw RuntimeException("HTTP " + code + ": " + m.take(160))
        }
        return s
    }

    private fun postModel(models: List<String>, prefKey: String, body: String): String {
        val saved = prefs.getString(prefKey, null)
        val order = if (saved != null && saved in models) listOf(saved) + models.filter { it != saved } else models
        var last: Exception? = null
        for (m in order) {
            try {
                val r = post(BASE + m + ":generateContent", body)
                prefs.edit().putString(prefKey, m).apply()
                return r
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("no model")
    }

    private fun appsList(): String {
        cachedApps?.let { return it }
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val names = pm.queryIntentActivities(i, 0).map { it.loadLabel(pm).toString() }.distinct().sorted().take(150)
        val s = names.joinToString(", ")
        cachedApps = s
        return s
    }

    private suspend fun think(text: String, img: String?): JSONObject = withContext(Dispatchers.IO) {
        if (apiKey.isBlank()) throw RuntimeException("no key")
        val ctx = StringBuilder()
        ctx.append("[Installed apps: ").append(appsList()).append("]\n")
        val acc = RituAccess.instance
        if (acc != null) ctx.append("[Screen now: ").append(acc.dump()).append("]\n")
        else ctx.append("[Accessibility OFF]\n")
        val parts = JSONArray().put(JSONObject().put("text", ctx.toString() + "Moshiur: " + text))
        if (img != null) parts.put(JSONObject().put("inline_data", JSONObject().put("mime_type", "image/jpeg").put("data", img)))
        val contents = JSONArray()
        history.takeLast(8).forEach { contents.put(it) }
        contents.put(JSONObject().put("role", "user").put("parts", parts))
        val body = JSONObject()
            .put("systemInstruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", SYS))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("responseMimeType", "application/json").put("temperature", 1.0))
        val resp = JSONObject(postModel(CHAT_MODELS, "chat_model", body.toString()))
        val ps = resp.getJSONArray("candidates").getJSONObject(0).getJSONObject("content").getJSONArray("parts")
        val raw = (0 until ps.length()).joinToString("") { ps.getJSONObject(it).optString("text", "") }
        val m = Regex("\\{[\\s\\S]*\\}").find(raw)
        val j = try { JSONObject(m!!.value) } catch (e: Exception) { JSONObject().put("reply", raw) }
        history.add(JSONObject().put("role", "user").put("parts", JSONArray().put(JSONObject().put("text", text))))
        history.add(JSONObject().put("role", "model").put("parts", JSONArray().put(JSONObject().put("text", j.optString("reply", raw)))))
        j
    }

    // ---------------------------------------------------------------- chat flow
    fun send(text: String) {
        val t = text.trim()
        if (t.isEmpty()) return
        messages.add(true to t)
        status = "ভাবছি…"
        scope.launch {
            try {
                respond(think(t, null))
                status = ""
            } catch (e: Exception) { fail(e) }
        }
    }

    fun sendPhoto(query: String, file: File) {
        scope.launch {
            try {
                status = "দেখছি…"
                val b64 = withContext(Dispatchers.IO) { photoToB64(file) }
                messages.add(true to ("📷 " + query))
                respond(think("(ছবি তুলেছি) " + query, b64))
                status = ""
            } catch (e: Exception) { fail(e) }
        }
    }

    private fun photoToB64(f: File): String {
        val o = BitmapFactory.Options().apply { inSampleSize = 4 }
        var bmp = BitmapFactory.decodeFile(f.absolutePath, o)
        val rot = when (ExifInterface(f.absolutePath).getAttributeInt(ExifInterface.TAG_ORIENTATION, 1)) {
            6 -> 90f
            3 -> 180f
            8 -> 270f
            else -> 0f
        }
        if (rot != 0f) {
            val m = Matrix()
            m.postRotate(rot)
            bmp = Bitmap.createBitmap(bmp, 0, 0, bmp.width, bmp.height, m, true)
        }
        val s = ByteArrayOutputStream()
        bmp.compress(Bitmap.CompressFormat.JPEG, 80, s)
        return Base64.encodeToString(s.toByteArray(), Base64.NO_WRAP)
    }

    private fun fail(e: Exception) {
        if (e is CancellationException) throw e
        val m = e.message ?: "error"
        status = when {
            apiKey.isBlank() -> "⚙️ থেকে Gemini API key দাও"
            m.contains("429") -> "Free limit শেষ, একটু পরে বলো"
            m.contains("400") || m.contains("403") -> "API key ঠিক নেই বা কাজ করছে না"
            else -> "সমস্যা: " + m.take(90)
        }
    }

    private suspend fun respond(j: JSONObject) {
        val reply = j.optString("reply", "")
        emotion = j.optString("emotion", "happy")
        if (reply.isNotBlank()) {
            messages.add(false to reply)
            lastReply = reply
            lastReplyAt = System.currentTimeMillis()
            say(reply)
        }
        val acts = j.optJSONArray("actions") ?: return
        for (i in 0 until acts.length()) {
            val go = try { runAction(acts.getJSONObject(i)) } catch (e: CancellationException) { throw e } catch (e: Exception) { status = "কাজটা করতে পারিনি: " + (e.message ?: "").take(60); true }
            if (!go) break
        }
    }

    // ---------------------------------------------------------------- actions
    private suspend fun runAction(a: JSONObject): Boolean {
        val acc = RituAccess.instance
        when (val type = a.optString("type")) {
            "open_app" -> { openApp(a.optString("name")); delay(1800) }
            "open_url" -> { openUrl(a.optString("url")); delay(1500) }
            "call" -> callTarget(a.optString("target"))
            "camera" -> {
                app.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                delay(1500)
            }
            "look" -> {
                app.startActivity(Intent(app, LookActivity::class.java).putExtra("q", a.optString("query", "এটা কী?")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                return false
            }
            "flashlight" -> torch(a.optBoolean("on", true))
            "volume" -> {
                val am = app.getSystemService(Context.AUDIO_SERVICE) as AudioManager
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, if (a.optString("dir") == "down") AudioManager.ADJUST_LOWER else AudioManager.ADJUST_RAISE, AudioManager.FLAG_SHOW_UI)
            }
            "wait" -> delay(a.optLong("ms", 1000).coerceIn(200L, 5000L))
            "click_text", "tap", "swipe", "scroll", "back", "home", "recents", "notifications", "type" -> {
                if (acc == null) { needAccess(); return false }
                acc.perform(type, a)
                delay(900)
            }
        }
        return true
    }

    private fun needAccess() {
        status = "অ্যাক্সেসিবিলিটি চালু করো (♿ বাটন)"
        if (!accWarned) {
            accWarned = true
            say("জানু, আগে অ্যাক্সেসিবিলিটি চালু করো, তাহলে আমি তোমার ফোন চালাতে পারব।")
        }
    }

    private fun openApp(name: String) {
        val pm = app.packageManager
        val i = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val l = pm.queryIntentActivities(i, 0)
        val r = l.firstOrNull { it.loadLabel(pm).toString().equals(name, true) }
            ?: l.firstOrNull { it.loadLabel(pm).toString().contains(name, true) }
        if (r == null) { status = "অ্যাপ পাইনি: " + name; return }
        val li = pm.getLaunchIntentForPackage(r.activityInfo.packageName) ?: return
        li.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(li)
    }

    private fun openUrl(url: String) {
        if (!url.startsWith("http")) return
        app.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
    }

    private fun lookupContact(name: String): String? {
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) return null
        val c = app.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(ContactsContract.CommonDataKinds.Phone.NUMBER),
            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?",
            arrayOf("%" + name + "%"), null
        ) ?: return null
        c.use { return if (it.moveToFirst()) it.getString(0) else null }
    }

    private fun callTarget(target: String) {
        var num = target.filter { it.isDigit() || it == '+' }
        if (num.length < 5 || target.any { it.isLetter() }) {
            val found = lookupContact(target)
            if (found == null) { status = "কন্টাক্ট পাইনি: " + target; return }
            num = found
        }
        val granted = ContextCompat.checkSelfPermission(app, Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        val i = Intent(if (granted) Intent.ACTION_CALL else Intent.ACTION_DIAL, Uri.parse("tel:" + Uri.encode(num)))
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        app.startActivity(i)
    }

    private fun torch(on: Boolean) {
        val cm = app.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true } ?: return
        cm.setTorchMode(id, on)
    }

    // ---------------------------------------------------------------- voice out
    private suspend fun ttsPcm(text: String, gv: String): ByteArray = withContext(Dispatchers.IO) {
        val cache = File(app.filesDir, "greet_" + gv + ".pcm")
        if (text == GREETING && cache.exists()) return@withContext cache.readBytes()
        val body = JSONObject()
            .put("contents", JSONArray().put(JSONObject().put("parts", JSONArray().put(JSONObject().put("text", STYLE + text)))))
            .put("generationConfig", JSONObject()
                .put("responseModalities", JSONArray().put("AUDIO"))
                .put("speechConfig", JSONObject().put("voiceConfig", JSONObject().put("prebuiltVoiceConfig", JSONObject().put("voiceName", gv)))))
        val resp = JSONObject(postModel(TTS_MODELS, "tts_model", body.toString()))
        val b64 = resp.getJSONArray("candidates").getJSONObject(0).getJSONObject("content")
            .getJSONArray("parts").getJSONObject(0).getJSONObject("inlineData").getString("data")
        val pcm = Base64.decode(b64, Base64.DEFAULT)
        if (text == GREETING) cache.writeBytes(pcm)
        pcm
    }

    private suspend fun play(pcm: ByteArray) {
        val min = AudioTrack.getMinBufferSize(24000, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
        val t = AudioTrack.Builder()
            .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            .setAudioFormat(AudioFormat.Builder().setSampleRate(24000).setChannelMask(AudioFormat.CHANNEL_OUT_MONO).setEncoding(AudioFormat.ENCODING_PCM_16BIT).build())
            .setBufferSizeInBytes(maxOf(min, pcm.size))
            .setTransferMode(AudioTrack.MODE_STATIC)
            .build()
        track = t
        try {
            t.write(pcm, 0, pcm.size)
            t.play()
            delay(pcm.size / 2 * 1000L / 24000 + 250)
        } finally {
            try { t.stop() } catch (e: Exception) { }
            t.release()
            track = null
        }
    }

    // ---- Free female neural voice (Microsoft Edge read-aloud, Bengali) - no API key, no daily limit
    @Volatile private var edgeSkew = 0L
    private var geminiOffUntil = 0L
    private var player: MediaPlayer? = null
    private val edgeClient by lazy {
        OkHttpClient.Builder().connectTimeout(15, TimeUnit.SECONDS).readTimeout(30, TimeUnit.SECONDS).build()
    }

    private fun cleanForSpeech(t: String): String =
        t.replace(Regex("[\\p{So}\\p{Cs}\\u200D\\uFE0F*_#~`]"), "").replace(Regex("\\s+"), " ").trim()

    private fun esc(t: String): String =
        t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;").replace("'", "&apos;")

    private fun sgn(n: Int): String = if (n >= 0) "+" + n else n.toString()

    // emotion -> (rate %, pitch Hz, volume %)
    private fun prosodyFor(emo: String): Triple<Int, Int, Int> = when (emo) {
        "happy" -> Triple(6, 6, 0)
        "shy" -> Triple(-10, 3, -12)
        "love" -> Triple(-8, 4, -6)
        "sad" -> Triple(-14, -6, -10)
        "surprised" -> Triple(10, 14, 4)
        else -> Triple(0, 3, 0)
    }

    // One <prosody> per sentence so questions rise, "!" is brighter and "…" slows down and pauses.
    private fun buildSsml(text: String, edgeName: String, emo: String): String {
        val (r0, p0, v0) = prosodyFor(emo)
        var parts = Regex("[^।?!.…]+[।?!.…]*").findAll(text).map { it.value.trim() }.filter { it.isNotEmpty() }.toList()
        if (parts.isEmpty()) parts = listOf(text)
        val sb = StringBuilder()
        sb.append("<speak version='1.0' xmlns='http://www.w3.org/2001/10/synthesis' xml:lang='en-US'>")
        sb.append("<voice name='Microsoft Server Speech Text to Speech Voice (")
            .append(edgeName.substringBeforeLast("-")).append(", ").append(edgeName.substringAfterLast("-")).append(")'>")
        var prevSlow = false
        parts.forEachIndexed { i, p ->
            var r = r0; var pt = p0; var v = v0
            when {
                p.endsWith("?") -> pt += 5
                p.endsWith("!") -> { r += 4; pt += 3; v += 4 }
                p.endsWith("…") -> { r -= 6; pt -= 1 }
            }
            if (i > 0) sb.append("<break time='").append(if (prevSlow) 450 else 220).append("ms'/>")
            sb.append("<prosody pitch='").append(sgn(pt)).append("Hz' rate='").append(sgn(r)).append("%' volume='").append(sgn(v)).append("%'>")
                .append(esc(p)).append("</prosody>")
            prevSlow = p.endsWith("…")
        }
        sb.append("</voice></speak>")
        return sb.toString()
    }

    private fun edgeGec(): String {
        var t = System.currentTimeMillis() / 1000 + edgeSkew + 11644473600L
        t -= t % 300
        val d = MessageDigest.getInstance("SHA-256").digest((t * 10000000L).toString().plus(EDGE_TOKEN).toByteArray(Charsets.US_ASCII))
        return d.joinToString("") { "%02X".format(it) }
    }

    private fun edgeStamp(): String {
        val f = SimpleDateFormat("EEE MMM dd yyyy HH:mm:ss", Locale.US)
        f.timeZone = TimeZone.getTimeZone("UTC")
        return f.format(Date()) + " GMT+0000 (Coordinated Universal Time)"
    }

    private fun edgeOnce(ssml: String): ByteArray {
        val reqId = UUID.randomUUID().toString().replace("-", "")
        val url = EDGE_URL + "?TrustedClientToken=" + EDGE_TOKEN + "&ConnectionId=" + reqId +
            "&Sec-MS-GEC=" + edgeGec() + "&Sec-MS-GEC-Version=" + EDGE_GEC_VERSION
        val req = Request.Builder().url(url)
            .header("Pragma", "no-cache")
            .header("Cache-Control", "no-cache")
            .header("Origin", "chrome-extension://jdiccldimpdaibmpdkjnbmckianbfold")
            .header("User-Agent", EDGE_UA)
            .header("Accept-Language", "en-US,en;q=0.9")
            .header("Cookie", "muid=" + UUID.randomUUID().toString().replace("-", "").uppercase() + ";")
            .build()
        val out = ByteArrayOutputStream()
        val latch = CountDownLatch(1)
        val ok = AtomicBoolean(false)
        val err = AtomicReference<Exception?>(null)
        val ws = edgeClient.newWebSocket(req, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                val ts = edgeStamp()
                webSocket.send(
                    "X-Timestamp:" + ts + "\r\nContent-Type:application/json; charset=utf-8\r\nPath:speech.config\r\n\r\n" +
                        "{\"context\":{\"synthesis\":{\"audio\":{\"metadataoptions\":{\"sentenceBoundaryEnabled\":\"false\",\"wordBoundaryEnabled\":\"false\"},\"outputFormat\":\"audio-24khz-48kbitrate-mono-mp3\"}}}}\r\n"
                )
                webSocket.send("X-RequestId:" + reqId + "\r\nContent-Type:application/ssml+xml\r\nX-Timestamp:" + ts + "Z\r\nPath:ssml\r\n\r\n" + ssml)
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                if (text.contains("Path:turn.end")) {
                    ok.set(true)
                    webSocket.close(1000, null)
                    latch.countDown()
                }
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val b = bytes.toByteArray()
                if (b.size < 2) return
                val hl = ((b[0].toInt() and 0xFF) shl 8) or (b[1].toInt() and 0xFF)
                if (b.size <= 2 + hl) return
                val hdr = String(b, 2, hl, Charsets.UTF_8)
                if (hdr.contains("Path:audio")) out.write(b, 2 + hl, b.size - 2 - hl)
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                val code = response?.code ?: 0
                if (code == 403) {
                    // wrong phone clock -> Sec-MS-GEC rejected; learn the server time for the retry
                    response?.headers?.getDate("Date")?.let { edgeSkew = it.time / 1000 - System.currentTimeMillis() / 1000 }
                }
                err.set(RuntimeException("edge " + code + ": " + (t.message ?: "")))
                latch.countDown()
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) { latch.countDown() }
        })
        if (!latch.await(30, TimeUnit.SECONDS)) {
            ws.cancel()
            throw RuntimeException("edge timeout")
        }
        err.get()?.let { throw it }
        if (!ok.get() || out.size() < 1000) throw RuntimeException("edge empty")
        return out.toByteArray()
    }

    private fun edgeMp3(ssml: String): ByteArray {
        var last: Exception? = null
        repeat(2) {
            try {
                return edgeOnce(ssml)
            } catch (e: Exception) {
                last = e
            }
        }
        throw last ?: RuntimeException("edge")
    }

    private suspend fun edgeFile(text: String, emo: String): File = withContext(Dispatchers.IO) {
        val name = EDGE_VOICES[voice] ?: EDGE_VOICES.values.first()
        val greet = text == GREETING
        val f = if (greet) File(app.filesDir, "greet_edge_" + name + ".mp3")
        else File(app.cacheDir, "say_" + System.nanoTime() + ".mp3")
        if (greet && f.exists() && f.length() > 1000) return@withContext f
        f.writeBytes(edgeMp3(buildSsml(cleanForSpeech(text), name, emo)))
        f
    }

    private suspend fun playMp3(f: File) = suspendCancellableCoroutine<Unit> { cont ->
        val mp = MediaPlayer()
        player = mp
        fun done() {
            try { mp.release() } catch (e: Exception) { }
            if (player === mp) player = null
        }
        cont.invokeOnCancellation { done() }
        try {
            mp.setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_MEDIA).setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build())
            mp.setDataSource(f.absolutePath)
            mp.setOnPreparedListener { it.start() }
            mp.setOnCompletionListener { done(); if (cont.isActive) cont.resume(Unit) }
            mp.setOnErrorListener { _, _, _ ->
                done()
                if (cont.isActive) cont.resumeWithException(RuntimeException("play error"))
                true
            }
            mp.prepareAsync()
        } catch (e: Exception) {
            done()
            if (cont.isActive) cont.resumeWithException(e)
        }
    }

    private suspend fun fallbackSpeak(text: String): Boolean {
        if (tts == null) {
            tts = TextToSpeech(app) { s ->
                if (s == TextToSpeech.SUCCESS) {
                    tts?.language = Locale("bn", "BD")
                    // last-resort phone voice: prefer a female Bengali voice if the engine exposes one
                    try {
                        val bn = tts?.voices?.filter { it.locale.language == "bn" } ?: emptyList()
                        val fem = bn.firstOrNull { it.name.contains("female", true) }
                        if (fem != null) tts?.voice = fem
                    } catch (e: Exception) { }
                    tts?.setPitch(1.12f)
                    tts?.setSpeechRate(0.95f)
                    ttsReady = true
                }
            }
        }
        var w = 0
        while (!ttsReady && w < 20) { delay(100); w++ }
        if (!ttsReady) return false
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "ritu")
        delay(text.length * 90L + 600)
        return true
    }

    fun say(text: String) {
        stopSpeaking()
        if (cleanForSpeech(text).isBlank()) return
        val emo = emotion
        speakJob = scope.launch {
            speaking = true
            var done = false
            try {
                // Selected engine first, the other one as backup, phone voice only as the very last resort.
                val order = if (voice in EDGE_VOICES) listOf(true, false) else listOf(false, true)
                for (useEdge in order) {
                    if (!useEdge && (apiKey.isBlank() || System.currentTimeMillis() < geminiOffUntil)) continue
                    try {
                        if (useEdge) {
                            val f = edgeFile(text, emo)
                            try { playMp3(f) } finally { if (f.name.startsWith("say_")) f.delete() }
                        } else {
                            play(ttsPcm(text, if (voice in VOICES) voice else VOICES[0]))
                        }
                        done = true
                        break
                    } catch (e: CancellationException) {
                        throw e
                    } catch (e: Exception) {
                        if (!useEdge && (e.message ?: "").contains("429")) geminiOffUntil = System.currentTimeMillis() + 10 * 60_000L
                    }
                }
                if (!done) {
                    status = "ভয়েস সার্ভার পাইনি (ইন্টারনেট?), ফোনের voice-এ বলছি"
                    done = fallbackSpeak(text)
                }
            } finally {
                speaking = false
            }
            if (done && autoListen) startListening()
        }
    }

    fun stopSpeaking() {
        speakJob?.cancel()
        speakJob = null
        try { player?.release() } catch (e: Exception) { }
        player = null
        try { track?.stop() } catch (e: Exception) { }
        try { tts?.stop() } catch (e: Exception) { }
        speaking = false
    }

    // ---------------------------------------------------------------- voice in
    fun startListening() {
        if (listening) return
        if (ContextCompat.checkSelfPermission(app, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            status = "মাইক পারমিশন দাও (Settings > Apps > Ritu > Permissions)"
            autoListen = false
            return
        }
        if (!SpeechRecognizer.isRecognitionAvailable(app)) {
            status = "এই ফোনে Google Speech নেই"
            autoListen = false
            return
        }
        stopSpeaking()
        val r = SpeechRecognizer.createSpeechRecognizer(app)
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(p: Bundle?) { status = "শুনছি জানু…" }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(v: Float) {}
            override fun onBufferReceived(b: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onError(e: Int) {
                listening = false
                releaseRec()
                autoListen = false
                status = if (e == SpeechRecognizer.ERROR_NO_MATCH || e == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) "কিছু শুনতে পাইনি" else "মাইক এরর (" + e + ")"
            }
            override fun onResults(b: Bundle?) {
                listening = false
                releaseRec()
                val t = b?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (t.isNullOrBlank()) status = "" else send(t)
            }
            override fun onPartialResults(b: Bundle?) {}
            override fun onEvent(t: Int, b: Bundle?) {}
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
        listening = true
        r.startListening(i)
    }

    private fun releaseRec() {
        val r = rec
        rec = null
        scope.launch { try { r?.destroy() } catch (e: Exception) { } }
    }

    fun stopListening() {
        autoListen = false
        try { rec?.stopListening() } catch (e: Exception) { }
    }

    fun toggleMic() {
        if (listening) stopListening() else { autoListen = true; startListening() }
    }
}
