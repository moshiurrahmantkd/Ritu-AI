package com.moshiur.ritu

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.FileProvider
import java.io.File

class LookActivity : ComponentActivity() {
    private var photo: File? = null
    private var query: String = ""

    private val launcher = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val f = photo
        if (ok && f != null) RituCore.sendPhoto(query, f)
        finish()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RituCore.init(applicationContext)
        query = intent.getStringExtra("q") ?: "এটা কী?"
        val f = File(cacheDir, "look.jpg")
        photo = f
        val uri = FileProvider.getUriForFile(this, "com.moshiur.ritu.files", f)
        launcher.launch(uri)
    }
}
