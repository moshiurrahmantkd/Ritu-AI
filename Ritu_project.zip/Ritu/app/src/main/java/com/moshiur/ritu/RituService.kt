package com.moshiur.ritu

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.provider.Settings
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.abs

class RituService : Service() {
    private var wm: WindowManager? = null
    private var root: LinearLayout? = null
    private val sc = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    override fun onCreate() {
        super.onCreate()
        RituCore.init(applicationContext)
        try {
            startFg()
        } catch (e: Exception) {
            Toast.makeText(this, "Overlay চালু হয়নি: মাইক পারমিশন দাও", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "'Display over other apps' পারমিশন দাও", Toast.LENGTH_LONG).show()
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildOverlay()
    }

    private fun startFg() {
        val ch = NotificationChannel("ritu", "Ritu", NotificationManager.IMPORTANCE_LOW)
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager).createNotificationChannel(ch)
        val pi = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "ritu")
            .setContentTitle("রিতু তোমার সাথেই আছে")
            .setContentText("বাবলে ট্যাপ করে কথা বলো, চেপে ধরলে বন্ধ হবে")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(pi)
            .build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(1, n)
    }

    private fun faceBitmap(): Bitmap {
        val b = BitmapFactory.decodeResource(resources, R.drawable.ritu_avatar)
        val x = (480f / 1660f * b.width).toInt()
        val y = (330f / 2290f * b.height).toInt()
        val sz = minOf((700f / 1660f * b.width).toInt(), b.width - x, b.height - y)
        return Bitmap.createBitmap(b, x, y, sz, sz)
    }

    private fun buildOverlay() {
        val d = resources.displayMetrics.density
        val size = (76 * d).toInt()
        val ring = GradientDrawable()
        ring.shape = GradientDrawable.OVAL
        ring.setColor(Color.parseColor("#FCD6C1"))
        ring.setStroke((3 * d).toInt(), Color.parseColor("#FF2BD6"))

        val bubble = ImageView(this)
        bubble.scaleType = ImageView.ScaleType.CENTER_CROP
        bubble.setImageBitmap(faceBitmap())
        bubble.background = ring
        bubble.clipToOutline = true

        val cap = TextView(this)
        cap.setTextColor(Color.WHITE)
        cap.textSize = 14f
        cap.maxWidth = (220 * d).toInt()
        cap.setPadding((12 * d).toInt(), (8 * d).toInt(), (12 * d).toInt(), (8 * d).toInt())
        val capBg = GradientDrawable()
        capBg.cornerRadius = 16 * d
        capBg.setColor(Color.parseColor("#EE2A0F28"))
        capBg.setStroke((1 * d).toInt(), Color.parseColor("#FF2BD6"))
        cap.background = capBg
        cap.visibility = android.view.View.GONE

        val r = LinearLayout(this)
        r.orientation = LinearLayout.HORIZONTAL
        r.gravity = Gravity.CENTER_VERTICAL
        r.addView(cap, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        r.addView(bubble, LinearLayout.LayoutParams(size, size))
        root = r

        val lp = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.END
        lp.x = (12 * d).toInt()
        lp.y = (160 * d).toInt()
        wm?.addView(r, lp)

        var sx = 0f
        var sy = 0f
        var ox = 0
        var oy = 0
        var t0 = 0L
        var moved = false
        bubble.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y
                    t0 = System.currentTimeMillis(); moved = false
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx
                    val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        lp.x = ox - dx.toInt()
                        lp.y = oy + dy.toInt()
                        wm?.updateViewLayout(r, lp)
                    }
                    true
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        if (System.currentTimeMillis() - t0 > 700) stopSelf() else RituCore.toggleMic()
                    }
                    true
                }
                else -> false
            }
        }

        sc.launch {
            while (true) {
                val col = when {
                    RituCore.listening -> "#00F0FF"
                    RituCore.speaking -> "#FFD34D"
                    else -> "#FF2BD6"
                }
                ring.setStroke((3 * d).toInt(), Color.parseColor(col))
                val text = when {
                    RituCore.listening -> "শুনছি জানু…"
                    RituCore.lastReply.isNotBlank() && (RituCore.speaking || System.currentTimeMillis() - RituCore.lastReplyAt < 8000) -> RituCore.lastReply
                    else -> ""
                }
                if (text.isEmpty()) {
                    cap.visibility = android.view.View.GONE
                } else {
                    cap.text = text
                    cap.visibility = android.view.View.VISIBLE
                }
                delay(250)
            }
        }
    }

    override fun onDestroy() {
        sc.cancel()
        RituCore.stopListening()
        RituCore.stopSpeaking()
        root?.let { try { wm?.removeView(it) } catch (e: Exception) { } }
        root = null
        super.onDestroy()
    }
}
