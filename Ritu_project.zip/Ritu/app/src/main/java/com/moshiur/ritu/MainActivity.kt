package com.moshiur.ritu

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import kotlinx.coroutines.delay

val Pink = Color(0xFFFF2BD6)
val Cyan = Color(0xFF00F0FF)

class MainActivity : ComponentActivity() {
    private val permLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        RituCore.init(applicationContext)
        val p = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.CALL_PHONE, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) p.add(Manifest.permission.POST_NOTIFICATIONS)
        permLauncher.launch(p.toTypedArray())
        setContent { MaterialTheme(colorScheme = darkColorScheme()) { RituApp() } }
    }
}

fun startOverlay(ctx: Context) {
    if (!Settings.canDrawOverlays(ctx)) {
        Toast.makeText(ctx, "Ritu কে 'Display over other apps' পারমিশন দাও, তারপর আবার 🫧 চাপো", Toast.LENGTH_LONG).show()
        ctx.startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + ctx.packageName)))
        return
    }
    if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
        Toast.makeText(ctx, "আগে মাইক পারমিশন দাও", Toast.LENGTH_LONG).show()
        return
    }
    ContextCompat.startForegroundService(ctx, Intent(ctx, RituService::class.java))
    Toast.makeText(ctx, "রিতু ভাসছে! এখন অন্য অ্যাপে যাও", Toast.LENGTH_SHORT).show()
}

@Composable
fun RituApp() {
    val ctx = LocalContext.current
    var settings by remember { mutableStateOf(RituCore.apiKey.isBlank()) }
    var input by remember { mutableStateOf("") }
    var accOn by remember { mutableStateOf(false) }
    val listState = rememberLazyListState()

    LaunchedEffect(Unit) { while (true) { accOn = RituAccess.instance != null; delay(1000) } }
    LaunchedEffect(Unit) {
        if (!RituCore.greeted) {
            RituCore.greeted = true
            RituCore.messages.add(false to RituCore.GREETING)
            RituCore.emotion = "love"
            RituCore.say(RituCore.GREETING)
        }
    }
    LaunchedEffect(RituCore.messages.size) {
        if (RituCore.messages.isNotEmpty()) listState.animateScrollToItem(RituCore.messages.size - 1)
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFF050509)).statusBarsPadding().navigationBarsPadding().imePadding().padding(10.dp)
    ) {
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
            Text("রিতু", style = TextStyle(color = Cyan, fontSize = 28.sp, fontWeight = FontWeight.Bold), modifier = Modifier.weight(1f))
            Chip("⚙️") { settings = true }
            Chip(if (accOn) "♿✅" else "♿") { ctx.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
            Chip("🫧") { startOverlay(ctx) }
        }
        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
            Avatar(RituCore.emotion, RituCore.speaking || RituCore.listening)
        }
        LazyColumn(state = listState, modifier = Modifier.fillMaxWidth().heightIn(max = 150.dp)) {
            items(RituCore.messages) { m -> MsgBubble(m.first, m.second) }
        }
        if (RituCore.status.isNotEmpty()) {
            Text(RituCore.status, color = Color.White.copy(alpha = 0.8f), fontSize = 12.sp, modifier = Modifier.padding(vertical = 3.dp))
        }
        Row(Modifier.fillMaxWidth().padding(top = 6.dp), verticalAlignment = Alignment.CenterVertically) {
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                modifier = Modifier.weight(1f),
                singleLine = true,
                placeholder = { Text("রিতুকে লেখো…", color = Color.White.copy(alpha = 0.5f)) },
                shape = RoundedCornerShape(24.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedTextColor = Color.White,
                    unfocusedTextColor = Color.White,
                    focusedBorderColor = Cyan,
                    unfocusedBorderColor = Cyan.copy(alpha = 0.6f),
                    cursorColor = Cyan
                )
            )
            Chip(if (RituCore.listening) "⏹" else "🎤") { RituCore.toggleMic() }
            Chip("➤") { if (input.isNotBlank()) { RituCore.send(input); input = "" } }
        }
    }
    if (settings) SettingsDialog { settings = false }
}

@Composable
fun Chip(t: String, onClick: () -> Unit) {
    Box(
        Modifier.padding(start = 6.dp)
            .border(1.5.dp, Pink, RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .padding(horizontal = 12.dp, vertical = 9.dp)
    ) { Text(t, fontSize = 18.sp, color = Color.White) }
}

@Composable
fun MsgBubble(me: Boolean, t: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp), horizontalArrangement = if (me) Arrangement.End else Arrangement.Start) {
        Text(
            t, color = Color.White, fontSize = 15.sp,
            modifier = Modifier.widthIn(max = 290.dp)
                .background(if (me) Color(0xFF0E2A33) else Color(0xFF2A0F28), RoundedCornerShape(14.dp))
                .border(1.dp, if (me) Cyan else Pink, RoundedCornerShape(14.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp)
        )
    }
}

@Composable
fun Avatar(emotion: String, active: Boolean) {
    val blink = remember { Animatable(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            delay((2500L..5500L).random())
            blink.animateTo(1f, tween(70))
            blink.animateTo(0f, tween(110))
        }
    }
    val inf = rememberInfiniteTransition(label = "glow")
    val g by inf.animateFloat(
        initialValue = 0.88f, targetValue = 1.1f,
        animationSpec = infiniteRepeatable(tween(if (active) 450 else 2200, easing = FastOutSlowInEasing), RepeatMode.Reverse),
        label = "g"
    )
    val blush by animateFloatAsState(
        targetValue = when (emotion) { "shy", "love" -> 0.9f; "happy" -> 0.5f; else -> 0.2f },
        label = "b"
    )
    val glowC = if (emotion == "sad") Color(0xFF3B6BFF) else Pink

    Box(Modifier.fillMaxHeight().aspectRatio(1660f / 2290f), contentAlignment = Alignment.Center) {
        Box(
            Modifier.fillMaxSize().scale(g * 1.08f)
                .background(Brush.radialGradient(listOf(glowC.copy(alpha = 0.55f), Cyan.copy(alpha = 0.18f), Color.Transparent)))
        )
        Image(painterResource(R.drawable.ritu_avatar), "Ritu", Modifier.fillMaxSize())
        Canvas(Modifier.fillMaxSize()) {
            val s = size.width / 1660f
            fun soft(cx: Float, cy: Float, rx: Float, ry: Float, a: Float) {
                for (k in 0..3) {
                    val f = 1f - k * 0.22f
                    drawOval(
                        Color(0xFFFF5C8A).copy(alpha = a * 0.28f),
                        Offset((cx - rx * f) * s, (cy - ry * f) * s),
                        Size(2 * rx * f * s, 2 * ry * f * s)
                    )
                }
            }
            fun lid(cx: Float, cy: Float, rx: Float, ry: Float, b: Float) {
                val top = (cy - ry) * s
                val h = 2 * ry * s * b
                drawOval(
                    Brush.verticalGradient(listOf(Color(0xFFFCD6C1), Color(0xFFFEE0CA)), startY = top, endY = top + 2 * ry * s),
                    Offset((cx - rx) * s, top),
                    Size(2 * rx * s, h)
                )
                if (b > 0.5f) {
                    drawLine(
                        Color(0xFF3A2218),
                        Offset((cx - rx * 0.9f) * s, top + h - 4 * s),
                        Offset((cx + rx * 0.9f) * s, top + h - 4 * s),
                        strokeWidth = 5 * s, cap = StrokeCap.Round
                    )
                }
            }
            soft(690f, 700f, 115f, 62f, blush)
            soft(945f, 705f, 115f, 62f, blush)
            val b = blink.value
            if (b > 0.02f) {
                lid(700f, 590f, 74f, 46f, b)
                lid(960f, 606f, 72f, 46f, b)
            }
        }
    }
}

@Composable
fun SettingsDialog(onClose: () -> Unit) {
    var key by remember { mutableStateOf(RituCore.apiKey) }
    var voice by remember { mutableStateOf(RituCore.voice) }
    AlertDialog(
        onDismissRequest = onClose,
        confirmButton = {
            TextButton(onClick = { RituCore.apiKey = key; RituCore.voice = voice; onClose() }) { Text("সেভ") }
        },
        title = { Text("সেটিংস") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Gemini API key (aistudio.google.com/apikey, free)", fontSize = 12.sp)
                OutlinedTextField(value = key, onValueChange = { key = it }, singleLine = true, visualTransformation = PasswordVisualTransformation())
                Spacer(Modifier.height(12.dp))
                Text("রিতুর গলা:")
                RituCore.VOICES.forEach { v ->
                    Text(
                        (if (v == voice) "● " else "○ ") + v,
                        modifier = Modifier.fillMaxWidth().clickable { voice = v }.padding(vertical = 8.dp)
                    )
                }
            }
        }
    )
}
