Ritu - AI girlfriend app (Gemini brain)
Build: gradle assembleDebug  (JDK 17, Gradle 8.9)
APK: app/build/outputs/apk/debug/app-debug.apk
